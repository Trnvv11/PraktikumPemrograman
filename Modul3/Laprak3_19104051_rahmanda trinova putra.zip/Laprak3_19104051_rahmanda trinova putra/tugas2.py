bilangan1 = float(input("Masukan bilangan yang akan dibagi: "))
bilangan2 = float(input("Masukan bilangan pembagi: "))

if bilangan2 != 0:
    hasil = bilangan1/bilangan2
    print("Hasil pembagian: ", hasil)
else:
    print("Pembagi tidak boleh (0).")